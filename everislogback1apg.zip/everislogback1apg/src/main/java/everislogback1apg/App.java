package everislogback1apg;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {
	
	final static Logger LOGGER = LoggerFactory.getLogger(App.class);
	
	public static void main(String[] args) {
		
		LOGGER.info(" = SEIS SÉXTUPLE = Inicio");
		
		int cuentaSeis = 0;
		int tiradaDado;
		
		for (int x=1; x <= 40000; x++) {
			tiradaDado = (int)(Math.random()*6 + 1);
			LOGGER.info("Tirada nº {}: Ha salido un {}",x,tiradaDado);
			
			if (tiradaDado == 6)
				cuentaSeis++;
			else
				cuentaSeis = 0;
			
			if (cuentaSeis == 6) {
				LOGGER.info("¡Se ha obtenido el seis séxtuple!");
				x = 40001;
			}
			
			if (x >= 40000 && cuentaSeis != 6) {
				LOGGER.info("No has conseguido el seis séxtuple, tú pierdes :)");
			}
		}
		
		LOGGER.info(" = SEIS SÉXTUPLE = Final");
	}
}
